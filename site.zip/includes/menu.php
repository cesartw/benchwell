    <header>
        <div class="container">
            <div class="row">
                <div class="col-7 col-md-3">
                    <a href="./"><img class="img-fluid" src="img/benchwell-logo.svg" title="BenchWell"></a>
                </div>
                <div class="col d-flex align-items-center">
                    <p class="text-right w-100 mb-0">
                        <a class="btn-social" href="#"><img src="img/discord-logo.svg" title="@user"></a>
                    </p>
                </div>
            </div>
        </div>
    </header>