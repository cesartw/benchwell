$(document).ready(function(){
  
    $(".owl-carousel").owlCarousel({
        loop:true,
        margin:20,
        nav:false,
        dots: true,
        items:1,
        autoplay: true,
        autoplayHoverPause: true,
        smartSpeed: 1000
    });

});