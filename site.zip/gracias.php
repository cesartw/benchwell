<!doctype html>
<?php include 'includes/header.php';?>

<html class="no-js" lang="en">

<body>

    <?php include 'includes/menu.php';?>

    <div id="slider" class="container mb-5">
        <div class="row">
            <div class="col-md-8">
                <img class="centrar" src="img/b-icon.svg">
                <h1><span>Mensaje de Gracias después de dejar el correo.</span></h1>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php';?>

</body>

</html>
